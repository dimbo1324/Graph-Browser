-- AlterTable
ALTER TABLE "Order" ALTER COLUMN "discountCodeId" DROP NOT NULL;
